# DMKD: mapa de revisores contra el PDF sometido confirmado

Referencia: PDF de 22 páginas aportado el 1 de octubre. Fuente revisada
provisional: recuperación `bb9c375`, no Overleaf actual confirmado. Las páginas
de esta matriz pertenecen al PDF sometido, no a una versión final inventada.

| Solicitud | Ubicación sometida | Estado de la revisión recuperada | Pendiente de cierre |
| --- | --- | --- | --- |
| R1.1: dos puntos | p. 6, definiciones | Etiquetas corregidas | Sincronizar con Overleaf. |
| R1.2: huecos en ecuación (5) | p. 6 | Aclara huecos en prosa; ecuación mantiene endpoint | Incorporar explícitamente el span y huecos para contestar la petición literal sin cambiar el descriptor. |
| R1.3: aclarar alcance relajado | pp. 6, 11, 15 | Prosa explicativa añadida | Usar ejemplos numéricos trazables; reconciliar PM2.5. |
| R1.4: unidades Tabla 2 | p. 11 | Unidades añadidas | Verificar redacción exacta de la escala Load; no rescalar datos. |
| R1.5 / R2.2: citar Figuras 1–3 | pp. 7, 8, 11–12 | Citas explícitas presentes | Revisar referencias tras compilación final. |
| R2.3: solapamiento Figura 1 | p. 7 | Redibujo recuperado | QA de la figura en la compilación canónica final. |
| R2.4: cajas Figura 2 | p. 8 | Cajas mayores y texto envuelto | QA en compilación final. |
| R1.6 / R2.5: baseline alternativo | §4.1, p. 7 | Sensibilidad estacional de cuatro dominios verificada numéricamente | Mantener separación del soporte primario y corregir la explicación PM2.5 no acreditada. No ejecutada otra vez. |
| R1.7 / R2.7: ARIMA(2,0,0) | p. 10; pp. 14–15; 17–19 | Comparaciones y claims retirados | Confirmar esa retirada en la fuente canónica y explicar sin inventar selección ACF/PACF. |
| R1.8–9 / R2.1: accionabilidad y utilidad adicional | Formulación y Discussion | Subapartado añadido | Acotar a diagnóstico de habilidad; ganancias pequeñas o incertidumbre pueden impedir utilidad real. |
| R1.10: rolling-window adaptativo y feedback | Discussion | Riesgo de selección adaptativa y validación independiente discutidos | No presentar un controlador dinámico como validado. |
| R2.6: caché única | p. 20 | README/manifest y recuperador único; Wind/Traffic no cacheados | Publicación verificable en ubicación controlada por autores; no marcar DONE solo por tener un script. |
| Editor: reporte exacto y limitaciones | Todo; apéndice pp. 19–20 | Existen mejoras de redacción | PM2.5 texto–figura; trazabilidad RMSE; protocolo real Load; autoría y versiones. |

La auditoría propia de RMSE, modelos y preparación no se atribuye a solicitudes
que los revisores no hicieron. Las respuestas explicarán los cambios realmente
realizados y los análisis históricos recuperados, no experimentos inexistentes.

Estado general: **revisión avanzada pero no finalizada**. El PDF aportado
resuelve la identidad de referencia; el ZIP/PDF actual de Overleaf es el
siguiente input necesario. El informe detallado está en
`docs/dmkd_submitted_pdf_identity_2026-10-01.md`.
